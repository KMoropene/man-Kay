// Initialize Firebase
const firebaseConfig = {
  apiKey: "AIzaSyAwJ9APZl_GSRrAbtiOF9s3HNbcAeeEylY",
  authDomain: "zidane-a422b.firebaseapp.com",
  databaseURL: "https://zidane-a422b-default-rtdb.firebaseio.com",
  projectId: "zidane-a422b",
  storageBucket: "zidane-a422b.appspot.com",
  messagingSenderId: "448452273990",
  appId: "1:448452273990:web:2f97e6fe95f510a70da747",
  measurementId: "G-JKX973TE0G"
};

firebase.initializeApp(firebaseConfig);

const database = firebase.database();

const registeredUsers = [];


// Get references to UI elements
const loginContainer = document.getElementById('loginContainer');
const dataContainer = document.getElementById('dataContainer');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const loginButton = document.getElementById('loginButton');
const logoutButton = document.getElementById('logoutButton');
const errorMessage = document.getElementById('errorMessage');

// Hide the data container initially
dataContainer.style.display = 'none';

// Function to show the data container after successful login
function showDataContainer() {
  loginContainer.style.display = 'none';
  dataContainer.style.display = 'block';
}

// Monitor user authentication state
firebase.auth().onAuthStateChanged((user) => {
  if (user) {
    // User is logged in
    showDataContainer();
    getRegisteredUsers((users) => {
      registeredUsers = users; // Store registered users in the global variable
    });
  } else {
    // User is not logged in
    loginContainer.style.display = 'block';
    dataContainer.style.display = 'none';
  }
});


// Function to handle login
function login() {
  const email = emailInput.value;
  const password = passwordInput.value;

  // Perform Firebase login
  firebase
    .auth()
    .signInWithEmailAndPassword(email, password)
    .then(() => {
      // Successful login
      showDataContainer();
	      loadAttendanceData();
          loadUserData();
      errorMessage.textContent = ''; // Clear error message
      errorMessage.style.color = 'red'; // Reset font color
    })
    .catch((error) => {
      // Failed login
      console.error('Login error:', error);
      errorMessage.textContent = 'Invalid email or password';
      errorMessage.style.color = 'red';
    });
}

// Add login button click event listener
loginButton.addEventListener('click', login);

// Function to handle logout
function logout() {
  firebase.auth().signOut()
    .then(() => {
      loginContainer.style.display = 'block';
      dataContainer.style.display = 'none';
    })
    .catch((error) => {
      console.error('Logout error:', error);
    });
}

logoutButton.addEventListener('click', logout);

// Monitor user authentication state
firebase.auth().onAuthStateChanged((user) => {
  if (user) {
    // User is logged in
    showDataContainer();
  } else {
    // User is not logged in
    loginContainer.style.display = 'block';
    dataContainer.style.display = 'none';
  }
});



// Function to open a specific tab
function openTab(tabId) {
  const tabcontent = document.getElementsByClassName('tabcontent');
  for (let i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = 'none';
  }

  document.getElementById(tabId).style.display = 'block';
}

// Display attendance records
const attendanceList = document.getElementById('attendanceList');
database.ref('/attendance').on('value', (snapshot) => {
  attendanceList.innerHTML = '';

  snapshot.forEach((nameSnapshot) => {
    const name = nameSnapshot.key;

    nameSnapshot.forEach((dateSnapshot) => {
      const date = dateSnapshot.key;
     // const status = dateSnapshot.val();
      const tr = document.createElement('tr'); // Create a table row

      const nameCell = document.createElement('td');
      nameCell.textContent = name;
      tr.appendChild(nameCell);

      const dateCell = document.createElement('td');
      dateCell.textContent = date;
      tr.appendChild(dateCell);

    //  const statusCell = document.createElement('td');
    //  statusCell.textContent = status;
     // tr.appendChild(statusCell);

      attendanceList.appendChild(tr);
    });
  });
}, (error) => {
  console.error('Error fetching attendance:', error);
});

// Display registered users
const userList = document.getElementById('userList');
database.ref('/users').on('value', (snapshot) => {
  userList.innerHTML = '';

  snapshot.forEach((userSnapshot) => {
    const name = userSnapshot.child('name').val();
    const password = userSnapshot.child('password').val();
    const tr = document.createElement('tr'); // Create a table row

    const nameCell = document.createElement('td');
    nameCell.textContent = name;
    tr.appendChild(nameCell);

    const passwordCell = document.createElement('td');
    passwordCell.textContent = "****";
    tr.appendChild(passwordCell);

    userList.appendChild(tr);
  });
}, (error) => {
  console.error('Error fetching users:', error);
});


// Register new user
const newUserName = document.getElementById('newUserName');
const newUserPassword = document.getElementById('newUserPassword');
const registerUserBtn = document.getElementById('registerUserBtn');

registerUserBtn.addEventListener('click', () => {
  const name = newUserName.value;
  const passcode = newUserPassword.value;

  if (name && passcode && /^[0-9]{4}$/.test(passcode)) {
    // Retrieve the last user's number
    database.ref('/users').orderByKey().limitToLast(1).once('value', (snapshot) => {
      let lastUserNumber = 0;

      snapshot.forEach((userSnapshot) => {
        const key = userSnapshot.key;
        const userNumber = parseInt(key.replace('user', ''));

        if (!isNaN(userNumber)) {
          lastUserNumber = userNumber;
        }
      });

      // Increment the last user's number and use it for the new user
      const newUserNumber = lastUserNumber + 1;

      // Save the new user to the database with the new user number
      const newUserRef = database.ref('/users/user' + newUserNumber);
      newUserRef.set({
        name: name,
        passcode: passcode
      });

      // Clear input fields
      newUserName.value = '';
      newUserPassword.value = '';

      alert('User registered successfully!');
    });
  } else {
    alert('Please enter a valid name and a 4-digit password.');
  }
});


// Add event listener to export button
exportAttendanceBtn.addEventListener('click', () => {
  const selectedDate = selectDate.value;
  getRegisteredUsers((users) => {
    const csvContent = generateCSVFromTable('attendanceList', selectedDate, users);

    if (csvContent) {
      downloadCSV(csvContent, `attendance_records_${selectedDate}.csv`);
    } else {
      alert('No attendance data found for the selected date.');
    }
  });
});


// Function to retrieve registered users
function getRegisteredUsers(callback) {
  const registeredUsers = [];

  database.ref('/users').on('value', (snapshot) => {
    snapshot.forEach((userSnapshot) => {
      const name = userSnapshot.child('name').val();
      registeredUsers.push({ name });
    });

    callback(registeredUsers);
  }, (error) => {
    console.error('Error fetching users:', error);
  });
}



// Function to generate CSV content from a table and a selected date
function generateCSVFromTable(tableId, selectedDate, registeredUsers) {
  const table = document.getElementById(tableId);
  const rows = table.querySelectorAll('tbody tr');

  let csvContent = 'Name,Date,Status\n'; // CSV header
  let foundData = false;
  const processedNames = {}; // To keep track of processed names

  // Create a date object from the selected date string
  const selectedDateObject = new Date(selectedDate);

  rows.forEach((row) => {
    const columns = row.querySelectorAll('td');
    const name = columns[0].textContent;
    const date = columns[1].textContent;
   // const status = columns[2].textContent;

    // Create a date object from the date string in the table
    const tableDateObject = new Date(date);

    // Compare only the date portion without the time
    if (
      tableDateObject.getFullYear() === selectedDateObject.getFullYear() &&
      tableDateObject.getMonth() === selectedDateObject.getMonth() &&
      tableDateObject.getDate() === selectedDateObject.getDate()
    ) {
		// Check if the name has already been processed for the selected date
      if (!processedNames[name]) {
        csvContent += `"${name}","${date}\n`;
        foundData = true;
        processedNames[name] = true;
      }
    }
  });

  // Include absent users
  registeredUsers.forEach((user) => {
    const userName = user.name;
    const userExistsInCSV = csvContent.includes(userName);
    
    if (!userExistsInCSV) {
      csvContent += `"${userName}","${selectedDate}","Absent"\n`;
      foundData = true;
    }
  });

  return foundData ? csvContent : null;
}


// Function to trigger CSV download
function downloadCSV(content, filename) {
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
